﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UpdateReferences.Utilities;

namespace UpdateReferences
{
    class Program
    {
        static void Main(string[] args)
        {
            var sln = @"D:\tmp\main\BDO.APT.Client\BDO.APT.Client.sln";
            var projs = ParseSln.GetProjects(sln);
            foreach (var proj in projs)
            {
                ParseSln.UpdateProj(proj);
            }
            Console.ReadKey();
        }
    }
}
